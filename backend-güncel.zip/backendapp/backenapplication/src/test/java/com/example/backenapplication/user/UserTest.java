package com.example.backenapplication.user;

import static org.junit.jupiter.api.Assertions.*;

class UserTest {

}