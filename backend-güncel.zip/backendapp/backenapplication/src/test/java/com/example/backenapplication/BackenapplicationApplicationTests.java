package com.example.backenapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackenapplicationApplicationTests {

    @Test
    void contextLoads() {
    }

}
