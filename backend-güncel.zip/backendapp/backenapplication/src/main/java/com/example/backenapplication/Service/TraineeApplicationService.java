package com.example.backenapplication.Service;
import lombok.Getter;
import org.springframework.stereotype.Service;
import com.example.backenapplication.repository.TraineeApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.ArrayList;
import java.util.List;
import com.example.backenapplication.user.TraineeApplication;
@Getter
@Service
public class TraineeApplicationService {

    private final TraineeApplicationRepository traineeApplicationRepository;

    @Autowired
    public TraineeApplicationService(TraineeApplicationRepository traineeApplicationRepository) {
        this.traineeApplicationRepository = traineeApplicationRepository;
    }

    public TraineeApplication createApplication(TraineeApplication application) {
        return traineeApplicationRepository.save(application);
    }

    public List<TraineeApplication> getApplications() {
        return traineeApplicationRepository.findAll();
    }

    public TraineeApplication getApplicationById(Long id) {
        return traineeApplicationRepository.findById(id).orElse(null);
    }

    public void deleteApplication(Long id) {
        traineeApplicationRepository.deleteById(id);
    }

}
