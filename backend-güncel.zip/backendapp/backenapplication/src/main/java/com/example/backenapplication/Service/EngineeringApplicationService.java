package com.example.backenapplication.Service;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.ArrayList;
import java.util.List;
import com.example.backenapplication.user.EngineeringApplication;
@Service
public class EngineeringApplicationService {


    public EngineeringApplication createApplication(EngineeringApplication application) {
        return application;
    }

    public List<EngineeringApplication> getApplications() {

        return List.of();
    }

    public EngineeringApplication getApplicationById(Long id) {
        return null;
    }

    public void deleteApplication(Long id) {
        return;

    }
}
