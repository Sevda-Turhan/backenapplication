package com.example.backenapplication.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.backenapplication.user.TraineeApplication;
import com.example.backenapplication.Service.TraineeApplicationService;

import java.util.List;

@RestController
@RequestMapping("/trainee")
public class TraineeApplicationController {

    private final TraineeApplicationService traineeApplicationService;

    @Autowired
    public TraineeApplicationController(TraineeApplicationService traineeApplicationService) {
        this.traineeApplicationService = traineeApplicationService;
    }

    @PostMapping("/apply")
    public TraineeApplication createApplication(@RequestBody TraineeApplication application) {
        return traineeApplicationService.createApplication(application);
    }

    @GetMapping("/applications")
    public List<TraineeApplication> getApplications() {
        return traineeApplicationService.getApplications();
    }

    @GetMapping("/applications/{id}")
    public TraineeApplication getApplicationById(@PathVariable Long id) {
        return traineeApplicationService.getApplicationById(id);
    }

    @DeleteMapping("/applications/{id}")
    public void deleteApplication(@PathVariable Long id) {
        traineeApplicationService.deleteApplication(id);
    }
}
