package com.example.backenapplication.user;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Setter;
import lombok.Getter;

@Getter
@Setter
@Entity
public class EngineeringApplication {
    @Id
    private Long id;
    private int projectCode;
    private String projectName;
    private String studentFirstName;
    private String studentLastName;
    private String email;
    private String status;

    // Constructor
    public EngineeringApplication(int projectCode, String projectName, String studentFirstName, String studentLastName, String email,String status) {
        this.projectCode = projectCode;
        this.projectName = projectName;
        this.studentFirstName = studentFirstName;
        this.studentLastName = studentLastName;
        this.email = email;
        this.status = status;

    }
    //Setter ve Getter
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public int getProjectCode() {
        return projectCode;

    }
    public void setProjectCode(int projectCode) {
        this.projectCode = projectCode;
    }
    public String getProjectName() {
        return projectName;
    }
    public void setProjectName(String projectName) {
        this.projectName = projectName;

    }
    public String getStudentFirstName() {
        return studentFirstName;

    }
    public void setStudentFirstName(String studentFirstName) {
        this.studentFirstName = studentFirstName;
    }
    public String getStudentLastName() {
        return studentLastName;

    }
    public void setStudentLastName(String studentLastName) {
        this.studentLastName = studentLastName;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;

    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

}
