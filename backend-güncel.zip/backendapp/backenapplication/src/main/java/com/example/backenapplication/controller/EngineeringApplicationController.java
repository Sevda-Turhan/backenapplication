package com.example.backenapplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.backenapplication.user.EngineeringApplication;
import com.example.backenapplication.Service.EngineeringApplicationService;

import java.util.List;

@RestController
@RequestMapping("/engineering-project")
public class EngineeringApplicationController {
    private final EngineeringApplicationService engineeringApplicationService;

    @Autowired
    public EngineeringApplicationController(EngineeringApplicationService engineeringApplicationService) {
        this.engineeringApplicationService = engineeringApplicationService;
    }

    @PostMapping("/apply")
    public EngineeringApplication createApplication(@RequestBody EngineeringApplication application) {
        return engineeringApplicationService.createApplication(application);
    }

    @GetMapping("/applications")
    public List<EngineeringApplication> getApplications() {
        return engineeringApplicationService.getApplications();
    }

    @GetMapping("/applications/{id}")
    public EngineeringApplication getApplicationById(@PathVariable Long id) {
        return engineeringApplicationService.getApplicationById(id);
    }

    @DeleteMapping("/applications/{id}")
    public void deleteApplication(@PathVariable Long id) {
        engineeringApplicationService.deleteApplication(id);
    }

}

