package com.example.backenapplication.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.backenapplication.repository.InternApplicationRepository;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import com.example.backenapplication.user.InternApplication;

@Service

public  class InternApplicationService {
    public  InternApplicationRepository internApplicationRepository;
    private Long id;

    @Autowired
    private InternApplicationService(InternApplicationRepository internApplicationRepository) {
        this.internApplicationRepository = internApplicationRepository;
    }
    private InternApplicationService() {
        this(null);
    }
    public static InternApplicationService createInternApplicationService(InternApplicationRepository internApplicationRepository) {
        return new InternApplicationService(internApplicationRepository);
    }


    public InternApplication createApplication(InternApplication application) {
        return internApplicationRepository.save(application);
    }

    public List<InternApplication> getApplications() {
        return internApplicationRepository.findAll();
    }

    public InternApplication getApplicationById(Long id) {
        return internApplicationRepository.findById(id).orElse(null);
    }

    public void deleteApplication(Long id) {
        this.id = id;
        internApplicationRepository.deleteById(id);
    }
}
